from django.http import HttpResponse
from django.shortcuts import render
from .models import *
from django.shortcuts import redirect
# FILE UPLOAD AND VIEW
from  django.core.files.storage import FileSystemStorage
# SESSION
from django.conf import settings

def first(request):
    return render(request,'index.html')


def login(request):
    return render(request,'login.html')

def addlogin(request):
    email=request.POST.get('email')
    password=request.POST.get('password')
    if email=='admin@gmail.com' and password=='admin':
        request.session['login_id']=email
        return render(request,'index.html')
    
    elif hodtable.objects.filter(email=email,password=password).exists():
        userdetails=hodtable.objects.get(email=request.POST['email'], password=password)
        if userdetails.password == request.POST['password']:
            request.session['hid'] = userdetails.id
            request.session['hname'] = userdetails.name
            return render(request,'index.html')
    elif teacher.objects.filter(email=email,password=password).exists():
        userdetails=teacher.objects.get(email=request.POST['email'], password=password)
        if userdetails.password == request.POST['password']:
            request.session['tid'] = userdetails.id
            request.session['tname'] = userdetails.name
            return render(request,'index.html')
        
    elif student_table.objects.filter(email=email,password=password).exists():
        userdetails=student_table.objects.get(email=request.POST['email'], password=password)
        if userdetails.password == request.POST['password']:
            request.session['sid'] = userdetails.id
            request.session['sname'] = userdetails.name
            return render(request,'index.html')
        
    return render(request,'login.html')
    

def logout(request):
    session_keys=list(request.session.keys())
    for key in session_keys:
        del request.session[key]
    return redirect(first)

def home(request):
    return render(request,'index.html')



def tech(request):
    return render(request,'staff.html')

def addteacher(request):
    if request.method=='POST':
        email=request.POST.get('email')
        password=request.POST.get('password')
        name=request.POST.get('name')
        phone=request.POST.get('phone')
     
        experience=request.POST.get('experience')
        qualification=request.POST.get('qualification')
        department=request.POST.get('department')
        dob=request.POST.get('dob')
        myfiles=request.FILES['idproof']
        fs=FileSystemStorage()
        filepath=fs.save(myfiles.name,myfiles)
        # filepath= "Testing"
        ins=teacher(name=name, email=email, phone=phone,
                    password=password, experience=experience,
                    qualification=qualification, department=department,
                    dob=dob, idproof=filepath)
        ins.save()
        
    return render(request,'index.html',{'message':"Successfully Registerd"})

def hod(request):
    return render(request,'hod.html')

def addhod(request):
    if request.method=='POST':
        email=request.POST.get('email')
        password=request.POST.get('password')
        name=request.POST.get('name')
        phone=request.POST.get('phone')
     
        experience=request.POST.get('experience')
        qualification=request.POST.get('qualification')
        department=request.POST.get('department')
        myfiles=request.FILES['idproof']
        fs=FileSystemStorage()
        filepath=fs.save(myfiles.name,myfiles)
        # filepath= "Testing"
        ins=hodtable(name=name, email=email, phone=phone,
                    password=password, experience=experience,
                    qualification=qualification, department=department,
                    idproof=filepath)
        ins.save()
        
    return render(request,'index.html',{'message':"Successfully Registerd"})
    return render(request,'hod.html')

def student(request):
    return render(request,'student.html')

def addstudent(request):
    if request.method=='POST':
        email=request.POST.get('email')
        password=request.POST.get('password')
        name=request.POST.get('name')
        phone=request.POST.get('phone')
        age=request.POST.get('age')
        dob=request.POST.get('dob')
        department=request.POST.get('department')
        myfiles=request.FILES['idproof']
        fs=FileSystemStorage()
        filepath=fs.save(myfiles.name,myfiles)
        # filepath= "Testing"
        ins=student_table(name=name, email=email, phone=phone,
                    password=password,age=age,
                    dob=dob,department=department,
                    idproof=filepath,status="pending")
        ins.save()
        
    return render(request,'student.html')
def viewstd(request):
    std=student_table.objects.all()
    return render(request,'viewstd.html',{'result':std})

def viewteacher(request):
    std=teacher.objects.all()
    return render(request,'viewteacher.html',{'result':std})
def feedback(request):
    return render(request,'feedback.html')

def addfeedback(request):
    if request.method=='POST':
        sname=request.session['sname']
        feedback=request.POST.get('feedback')
        
        
        cus=feedtable(user_id=sname,feedback=feedback)
        cus.save()
    return render(request,"index.html",{'feedback':'sucessfully Added'})

def viewfeedback(request):
    fdb=feedtable.objects.all()
    return render(request,'viewfeedback.html',{'result':fdb})
def viewstudent(request):
    return render(request,'viewstudent.html')
def viewstudent(request):
    fdb=student_table.objects.all()
    return render(request,'viewstudent.html',{'result':fdb})  

def delete(request,id):
    user=student_table.objects.get(id=id)
    user.delete()
    return redirect(viewstudent)  

def notes(request):
    return render(request,'notes.html')

def addnotes(request):
    myfiles=request.FILES['notes']
    fs=FileSystemStorage()
    filepath=fs.save(myfiles.name,myfiles)
    
def profile(request):
    
    id=request.session['sid']   
    a=student_table.objects.get(id=id) 
    return render (request,'pofile.html')
    
    



