from django.db import models

class teacher(models.Model):
    email = models.CharField(max_length=150)
    password = models.CharField(max_length=150)
    name = models.CharField(max_length=150)
    phone = models.CharField(max_length=150)
    experience = models.CharField(max_length=150)
    qualification = models.CharField(max_length=150)
    department = models.CharField(max_length=150)
    dob= models.CharField(max_length=150)
    idproof= models.FileField(max_length=255)
    
    
class hodtable(models.Model):
    email = models.CharField(max_length=150)
    password = models.CharField(max_length=150)
    name = models.CharField(max_length=150)
    phone = models.CharField(max_length=150)
    experience = models.CharField(max_length=150)
    qualification = models.CharField(max_length=150)
    department = models.CharField(max_length=150)    
    idproof= models.FileField(max_length=255)
    
class student_table(models.Model):
    email = models.CharField(max_length=150)
    password = models.CharField(max_length=150)
    name = models.CharField(max_length=150)
    phone = models.CharField(max_length=150)
    dob = models.CharField(max_length=150)
    department = models.CharField(max_length=150)    
    idproof= models.FileField(max_length=255)
    age=models.CharField(max_length=5)
    status=models.CharField(max_length=150)
    
class Department(models.Model):
    CSE = models.CharField(max_length=150)
    IT = models.CharField(max_length=150)
    EEE = models.CharField(max_length=150)
    MECH = models.CharField(max_length=150)
    ECE = models.CharField(max_length=150)
    
class feedtable(models.Model):
    user_id=models.CharField(max_length=150)
    feedback=models.CharField(max_length=150)
    
    
class assign_table(models.Model):
    hod_id=models.CharField(max_length=150)
    teacher_id=models.CharField(max_length=150)
    subject_name=models.CharField(max_length=150)
 
class uploadnotes(models.Model):
    image=models.FileField(max_length=250)
    Subject_name=models.CharField(max_length=150)
    
        

    
    
